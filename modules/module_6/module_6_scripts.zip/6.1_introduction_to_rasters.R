# My code for the introduction to rasters tutorial

# setup -------------------------------------------------------------------

library(tidyterra)
library(sf)
library(tidyverse)

# Load the source script:

source("scripts/source_script_module_3.R")

# read and pre-process data -----------------------------------------------

# Campus elevation model:

dem <-
  terra::rast("data/raw/gis_scbi/scbi_dem.tif") %>%
  rename(elevation = 1)

# Now you! Also read `dc_stack.tif`, from `data/raw/rasters`, assigned to
# the name `dc`.



# visualizing raster data -------------------------------------------------

# Map the elevation model:

ggplot() +

  # Add geometries:

  geom_spatraster(data = dem) +

  # Define scale elements:

  scale_fill_hypso_c() +

  # Modify the theme:

  theme_bw()

# values on disk and in memory --------------------------------------------

# Are the values in memory?

terra::inMemory(dem)

# summarizing raster values -----------------------------------------------

# Summarize the layer:

dem %>%
  terra::global(
    c(
      "mean",
      "sd",
      "min",
      "max"
    )
  )

# Now you! Return the mean of each of the four layers of `dc`, ignoring
# missing cells, and say why the `land` layer's mean is what it is.



# raster resolution and cell area -----------------------------------------

# Mean cell area:

dem %>%
  terra::cellSize(unit = "m") %>%
  terra::global("mean")

# multi-layer rasters -----------------------------------------------------

# Combine two layers of `dc`:

dc_surfaces <-
  c(
    dc %>%
      select(canopy),
    dc %>%
      select(imp)
  ) %>%
  rename(impervious = imp)

# Select the canopy layer:

dc_surfaces %>%
  select(canopy)

# Lowest campus elevation:

low_point <-
  dem %>%
  terra::global("min") %>%
  pull(min)

# Height above the lowest point:

dem %>%
  mutate(
    relative_elevation = elevation - low_point
  )

# Now you! Return a raster of the Washington, D.C. area holding canopy cover
# only where impervious surface is below ten percent, then count the cells
# that still hold a value.



# filtering raster values -------------------------------------------------

# Cells above 350 meters:

dem %>%
  filter(elevation > 350)

# Count the cells:

dem %>%
  filter(elevation > 350) %>%
  terra::ncell()

# Count the empty cells:

dem %>%
  filter(elevation > 350) %>%
  is.na() %>%
  terra::global("sum")

# Count the cells with values:

dem %>%
  filter(elevation > 350) %>%
  terra::not.na() %>%
  terra::global("sum")

# Now you! Return the total area above 350 meters in hectares. Why would
# `ncell()` give the wrong answer?


