# My code for the introduction to Shiny tutorial

# setup -------------------------------------------------------------------

library(shiny)
library(tidyterra)
library(tidyverse)

# Elevation model in UTM zone 17N:

dem <-
  terra::rast("data/raw/gis_scbi/scbi_dem.tif") %>%
  terra::project("EPSG:26917") %>%
  rename(elevation = 1)

# Cell area in hectares:

cell_area <-
  dem %>%
  terra::cellSize(
    unit = "ha",
    transform = FALSE
  )

# user interface ----------------------------------------------------------

ui <-
  fluidPage(
    titlePanel("Elevation at SCBI"),
    sidebarLayout(
      sidebarPanel(
        sliderInput(
          inputId = "cutoff",
          label = "Show ground above (meters):",
          min = 224,
          max = 392,
          value = 300
        )
      ),
      mainPanel(
        plotOutput("map"),
        textOutput("area")
      )
    )
  )

# server ------------------------------------------------------------------

server <-
  function(input, output, session) {

    # Ground above the cutoff:

    high_ground <-
      reactive({
        dem %>%
          filter(elevation > input$cutoff)
      })

    # Map the high ground:

    output$map <-
      renderPlot({
        ggplot() +

          # Add geometries:

          geom_spatraster(data = high_ground()) +

          # Define scale elements:

          scale_fill_hypso_c(na.value = "grey90") +

          # Modify the theme:

          theme_void()
      })

    # Area above the cutoff:

    output$area <-
      renderText({
        hectares <-
          cell_area %>%
          terra::mask(high_ground()) %>%
          terra::global("sum", na.rm = TRUE) %>%
          pull(sum) %>%
          round(1)

        glue::glue("{hectares} hectares above {input$cutoff} meters")
      })
  }

# run the app -------------------------------------------------------------

shinyApp(ui, server)

# Now you! Add a checkbox that lets the reader decide whether the ground
# below the selected elevation is drawn in grey or left transparent.


