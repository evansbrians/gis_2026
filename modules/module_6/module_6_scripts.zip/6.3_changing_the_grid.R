# My code for the changing the grid tutorial

# setup -------------------------------------------------------------------

library(tidyterra)
library(sf)
library(tidyverse)

# Load the source script:

source("scripts/source_script_module_3.R")

# read and pre-process data -----------------------------------------------

# Campus elevation model:

dem <-
  terra::rast("data/raw/gis_scbi/scbi_dem.tif")

# Campus canopy cover:

canopy <-
  terra::rast("data/raw/gis_scbi/scbi_canopy_cover.tif")

# diagnosing grid mismatches ----------------------------------------------

# Compare the grids:

terra::compareGeom(
  dem,
  canopy,
  stopOnError = FALSE,
  messages = TRUE
)

# Add the rasters (returns an error):

dem + canopy

# Compare resolutions:

terra::res(dem)

terra::res(canopy)

# Compare extents:

terra::ext(dem)

terra::ext(canopy)

# Compare origins:

terra::origin(dem)

terra::origin(canopy)

# Range of cell areas:

dem %>%
  terra::cellSize(unit = "m") %>%
  terra::global(c("min", "max"))

# projecting a raster -----------------------------------------------------

# Project to UTM zone 17N:

dem_utm <-
  dem %>%
  terra::project("EPSG:26917")

# Compare cell counts:

terra::ncell(dem)

terra::ncell(dem_utm)

# projecting a categorical raster -----------------------------------------

# Campus land cover:

lc <-
  terra::rast("data/raw/gis_scbi/scbi_lc.tif")

# Project with nearest neighbor:

lc_utm <-
  lc %>%
  terra::project(
    "EPSG:26917",
    method = "near"
  )

# Are classes and colors retained?

terra::is.factor(lc_utm)

terra::has.colors(lc_utm)

# Project with bilinear:

lc %>%
  terra::project(
    "EPSG:26917",
    method = "bilinear"
  ) %>%
  terra::is.factor()

# aggregating and disaggregating rasters ----------------------------------

# Aggregate by a factor of ten:

dem_coarse <-
  dem %>%
  terra::aggregate(
    fact = 10,
    fun = "mean",
    na.rm = TRUE
  )

# Aggregate, then disaggregate:

dem %>%
  terra::aggregate(
    fact = 10,
    fun = "mean",
    na.rm = TRUE
  ) %>%
  terra::disagg(fact = 10) %>%
  dim()

# Original dimensions:

dim(dem)

# Count missing aggregated cells:

dem %>%
  terra::aggregate(
    fact = 10,
    fun = "mean"
  ) %>%
  is.na() %>%
  terra::global("sum")

# resampling to a target grid ---------------------------------------------

# Resample canopy onto the elevation grid:

canopy_on_dem <-
  canopy %>%
  terra::resample(
    dem,
    method = "bilinear"
  )

# Add the rasters:

dem + canopy_on_dem

# Stack the rasters:

campus <-
  c(dem, canopy_on_dem)

# Name the layers:

names(campus) <-
  c("elevation", "canopy")

# Now you! Put the land cover raster onto the grid of the elevation raster,
# keeping its classes intact, and confirm that the classes were retained.


