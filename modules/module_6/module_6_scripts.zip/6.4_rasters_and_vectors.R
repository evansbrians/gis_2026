# My code for the rasters and vectors tutorial

# setup -------------------------------------------------------------------

library(tidyterra)
library(sf)
library(tidyverse)

# Load the source script:

source("scripts/source_script_module_3.R")

# read and pre-process data -----------------------------------------------

# Campus elevation model:

dem <-
  terra::rast("data/raw/gis_scbi/scbi_dem.tif")

# Name the layer:

names(dem) <- "elevation"

# Campus land cover:

lc <-
  terra::rast("data/raw/gis_scbi/scbi_lc.tif")

# Name the layer:

names(lc) <- "land_cover"

# CRS of the rasters:

raster_crs <-
  st_crs(dem)

# Campus boundary:

campus <-
  st_read(
    "data/raw/gis_scbi/smsc_campus_scbi.geojson",
    quiet = TRUE
  ) %>%
  st_transform(crs = raster_crs)

# iNaturalist observations:

observations <-
  st_read(
    "data/raw/gis_scbi/inat_scbi.geojson",
    quiet = TRUE
  ) %>%
  st_transform(crs = raster_crs)

# Campus roads:

roads <-
  st_read(
    "data/raw/gis_scbi/roads_scbi.geojson",
    quiet = TRUE
  ) %>%
  clean_names() %>%
  select(name) %>%
  st_transform(crs = raster_crs)

# converting between sf and spatvector objects ----------------------------

# Convert to a SpatVector:

campus_v <-
  terra::vect(campus)

# Convert back to sf:

campus_v %>%
  st_as_sf() %>%
  class()

# cropping and masking with vector boundaries -----------------------------

# Crop to the campus:

campus_dem <-
  dem %>%
  terra::crop(campus_v)

# Mask to the campus:

campus_only <-
  campus_dem %>%
  terra::mask(campus_v)

campus_only %>%
  is.na() %>%
  terra::global("sum")

# Map the masked elevation:

ggplot() +

  # Add geometries:

  geom_spatraster(data = campus_only) +
  geom_sf(
    data = campus,
    fill = NA,
    color = "red"
  ) +

  # Define scale elements:

  scale_fill_hypso_c()

# Crop and mask together:

dem %>%
  terra::crop(campus_v, mask = TRUE)

# Crop with a mismatched CRS (returns an error):

dem %>%
  terra::crop(
    campus %>%
      st_transform(crs = 32617) %>%
      terra::vect()
  )

# Mask with a mismatched CRS:

dem %>%
  terra::mask(
    campus %>%
      st_transform(crs = 32617) %>%
      terra::vect()
  ) %>%
  is.na() %>%
  terra::global("sum")

# extracting raster values at vector locations ----------------------------

# Elevation at each observation:

elevations <-
  dem %>%
  terra::extract(
    terra::vect(observations)
  )

elevations %>%
  head()

# Add elevation to the observations:

observations_with_elevation <-
  observations %>%
  mutate(
    elevation =
      elevations %>%
      pull(elevation)
  )

observations_with_elevation %>%
  st_drop_geometry() %>%
  head(4)

# Land cover at each observation:

land_cover <-
  lc %>%
  terra::extract(
    terra::vect(observations)
  )

land_cover %>%
  count(land_cover) %>%
  arrange(desc(n))

# Mean elevation of the campus:

dem %>%
  terra::extract(
    campus_v,
    fun = mean,
    na.rm = TRUE
  )

# Area-weighted mean elevation:

dem %>%
  terra::extract(
    campus_v,
    fun = mean,
    na.rm = TRUE,
    exact = TRUE
  )

# Now you! Return the median elevation of the observations in each land
# cover class.



# rasterizing vector features ---------------------------------------------

# Rasterize the roads:

road_cells <-
  roads %>%
  terra::vect() %>%
  terra::rasterize(
    dem,
    field = 1
  )

road_cells %>%
  terra::freq()

# Count observations per cell:

observation_counts <-
  observations %>%
  terra::vect() %>%
  terra::rasterize(
    dem %>%
      terra::aggregate(fact = 20),
    fun = "length",
    background = 0
  )

observation_counts %>%
  terra::global(c("max", "sum"))

# Map the observation counts:

ggplot() +

  # Add geometries:

  geom_spatraster(data = observation_counts) +

  # Define scale elements:

  scale_fill_whitebox_c(palette = "deep")

# converting raster classes to polygons -----------------------------------

# Crop and mask land cover:

lc_campus <-
  lc %>%
  terra::crop(
    campus_v,
    mask = TRUE
  )

# One polygon per class:

lc_polygons <-
  lc_campus %>%
  terra::as.polygons()

# Largest classes by area:

lc_polygons %>%
  st_as_sf() %>%
  mutate(
    area = st_area(geometry)
  ) %>%
  st_drop_geometry() %>%
  arrange(desc(area)) %>%
  head(4)
