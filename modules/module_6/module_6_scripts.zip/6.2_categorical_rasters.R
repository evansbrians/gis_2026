# My code for the categorical rasters tutorial

# setup -------------------------------------------------------------------

library(tidyterra)
library(sf)
library(tidyverse)

# Load the source script:

source("scripts/source_script_module_3.R")

# read and pre-process data -----------------------------------------------

# Campus land cover:

lc <-
  terra::rast("data/raw/gis_scbi/scbi_lc.tif")

# Campus elevation model:

dem <-
  terra::rast("data/raw/gis_scbi/scbi_dem.tif")

# categorical raster structure --------------------------------------------

# Is the layer categorical?

terra::is.factor(lc)

# Category table:

terra::cats(lc)[[1]]

# Cells per class:

lc %>%
  terra::freq() %>%
  arrange(desc(count))

# Now you! How much of this extent is forest, as a proportion of the
# classified cells?



# visualizing categorical rasters -----------------------------------------

# Map with the stored color table:

ggplot() +

  # Add geometries:

  geom_spatraster(data = lc)

# The color table:

terra::coltab(lc)[[1]] %>%
  head()

# classifying continuous values -------------------------------------------

# Elevation range:

elevation_range <-
  dem %>%
  terra::global(c("min", "max"))

# Elevation bands:

elevation_bands <-
  matrix(
    c(
      elevation_range$min, 250, 1,
      250, 300, 2,
      300, 350, 3,
      350, 400, 4
    ),
    ncol = 3,
    byrow = TRUE
  )

# class interval boundaries -----------------------------------------------

# Compare interval rules:

tibble(
  elevation = c(224, 250, 300, 350, 400)
) %>%
  mutate(
    default =
      cut(
        elevation,
        breaks = c(224, 250, 300, 350, 400)
      ),
    include_lowest =
      cut(
        elevation,
        breaks = c(224, 250, 300, 350, 400),
        include.lowest = TRUE
      ),
    left_closed =
      cut(
        elevation,
        breaks = c(224, 250, 300, 350, 400),
        include.lowest = TRUE,
        right = FALSE
      )
  )

# Classify into bands:

elevation_zones <-
  dem %>%
  terra::classify(
    elevation_bands,
    include.lowest = TRUE
  )

elevation_zones %>%
  terra::freq()

# Bands that miss the lowest values:

dem %>%
  terra::classify(
    matrix(
      c(
        250, 300, 2,
        300, 350, 3,
        350, 400, 4
      ),
      ncol = 3,
      byrow = TRUE
    )
  ) %>%
  terra::freq() %>%
  head(4)

# Set unmatched values to NA:

dem %>%
  terra::classify(
    matrix(
      c(
        250, 300, 2,
        300, 350, 3,
        350, 400, 4
      ),
      ncol = 3,
      byrow = TRUE
    ),
    others = NA
  ) %>%
  terra::freq()

# Is the result categorical?

terra::is.factor(elevation_zones)

# Attach zone labels:

levels(elevation_zones) <-
  tibble(
    value = 1:4,
    zone =
      c(
        "Lowest elevation",
        "Lower elevation",
        "Higher elevation",
        "Highest elevation"
      )
  ) %>%
  as.data.frame()

elevation_zones %>%
  terra::freq()

terra::is.factor(elevation_zones)

# Map the elevation zones:

ggplot() +

  # Add geometries:

  geom_spatraster(data = elevation_zones) +

  # Define scale elements:

  scale_fill_brewer(
    palette = "YlOrBr",
    na.value = "transparent"
  ) +

  # Add labels:

  labs(fill = "Zone")

# merging classes ---------------------------------------------------------

# County land cover key:

lc_key <-
  read_csv(
    "data/raw/gis_scbi/lc_key_warren_county_va.csv",
    show_col_types = FALSE
  ) %>%
  clean_names() %>%
  select(
    value,
    detailed = landuse,
    general = genlanduse
  )

lc_key %>%
  head(6)

# Number the general groups:

group_key <-
  lc_key %>%
  distinct(general) %>%
  arrange(general) %>%
  mutate(group_id = row_number())

group_key %>%
  head(6)

# Join the keys to the categories:

groups <-
  lc %>%
  terra::cats() %>%
  pluck(1) %>%
  left_join(
    lc_key,
    by = join_by(value)
  ) %>%
  left_join(
    group_key,
    by = join_by(general)
  )

groups %>%
  select(
    value,
    category,
    general,
    group_id
  ) %>%
  head(6)

# Codes missing from the key:

groups %>%
  filter(is.na(group_id))

# Relabel without reclassifying:

relabeled <- lc

levels(relabeled) <-
  groups %>%
  select(value, general) %>%
  as.data.frame()

relabeled %>%
  terra::freq() %>%
  head(8)

# Reclassify the codes:

general_cover <-
  lc %>%
  terra::classify(
    groups %>%
      select(value, group_id) %>%
      as.matrix()
  )

# Attach the group labels:

levels(general_cover) <-
  groups %>%
  distinct(group_id, general) %>%
  arrange(group_id) %>%
  as.data.frame()

general_cover %>%
  terra::freq() %>%
  arrange(desc(count))
